<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Xavier App</title>
	<script src="https://js.paystack.co/v1/inline.js"></script>
	@vite('resources/js/app.js')
  </head>
  <body class="antialiased">
    <div id="app"></div>
  </body>
</html>
