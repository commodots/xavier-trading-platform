<template>
  <div class="p-8 text-white">
    <h1 class="text-2xl font-bold mb-4">Settings</h1>
    <p>This is your Settings page. You can update your personal info here.</p>
  </div>
</template>
