<template>
  <router-view />
</template>

<script setup>
// No script needed — this just loads your routed pages
</script>

<style>
body {
  @apply bg-slate-900 text-white;
}
</style>
