<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Xavier App</title>
	<script src="https://js.paystack.co/v1/inline.js"></script>
	<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
  </head>
  <body class="antialiased">
    <div id="app"></div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\xavier-backend\resources\views/app.blade.php ENDPATH**/ ?>